self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "cc08c30275c672729347f9facfa8e43f",
    "url": "/bls-polymers/index.html"
  },
  {
    "revision": "c1b1a1a9eda0c59f47a9",
    "url": "/bls-polymers/static/css/2.b71989ea.chunk.css"
  },
  {
    "revision": "0ad8179e81c40e1d8480",
    "url": "/bls-polymers/static/css/main.70469a11.chunk.css"
  },
  {
    "revision": "c1b1a1a9eda0c59f47a9",
    "url": "/bls-polymers/static/js/2.ec18a11a.chunk.js"
  },
  {
    "revision": "630be3b6c0cac605a15013b777e3b263",
    "url": "/bls-polymers/static/js/2.ec18a11a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "71ab057e25d85cdaac14",
    "url": "/bls-polymers/static/js/3.c126e2bc.chunk.js"
  },
  {
    "revision": "0ad8179e81c40e1d8480",
    "url": "/bls-polymers/static/js/main.bea23169.chunk.js"
  },
  {
    "revision": "12c098ba75ec7b0aa1e6",
    "url": "/bls-polymers/static/js/runtime-main.886ffe79.js"
  },
  {
    "revision": "025aac0cc91e344a2e40e1b27dcf029c",
    "url": "/bls-polymers/static/media/Banner_1.025aac0c.jpg"
  },
  {
    "revision": "3378bb85badd776380a4de436ba97340",
    "url": "/bls-polymers/static/media/Banner_2.3378bb85.jpg"
  },
  {
    "revision": "432786bb5c4d7939dbd179206c1383ec",
    "url": "/bls-polymers/static/media/Banner_2.432786bb.png"
  },
  {
    "revision": "470d5c90129a865f1f528d9c3d2f7cb9",
    "url": "/bls-polymers/static/media/Banner_3.470d5c90.png"
  },
  {
    "revision": "efc93c7023227ca2adbfa58a302b38f5",
    "url": "/bls-polymers/static/media/Banner_3.efc93c70.jpg"
  },
  {
    "revision": "e45880d87842dc418cc89a7199b9bed0",
    "url": "/bls-polymers/static/media/Clients_bg.e45880d8.jpg"
  },
  {
    "revision": "c3a7070c0cc0196e64a45cc01ac0f0c2",
    "url": "/bls-polymers/static/media/EIL-CERTIFICATION.c3a7070c.pdf"
  },
  {
    "revision": "723ec93eb6423b8ccfed677172d60bd7",
    "url": "/bls-polymers/static/media/EIL-CERTIFICATION_page-0001.723ec93e.jpg"
  },
  {
    "revision": "bf610514efb5dd2e5e8883f83d491e16",
    "url": "/bls-polymers/static/media/ISO-9001-2015-Certificate.bf610514.pdf"
  },
  {
    "revision": "f1064086529f3d75362a9547e0d63f0c",
    "url": "/bls-polymers/static/media/ISO-9001-2015-Certificate_page-0001.f1064086.jpg"
  },
  {
    "revision": "24d113f0e9ce95d5bd6b84aeae83c2b4",
    "url": "/bls-polymers/static/media/News_03.24d113f0.jpg"
  },
  {
    "revision": "78558b7da80880b7153aedde44a5cc5c",
    "url": "/bls-polymers/static/media/about-bg.78558b7d.jpg"
  },
  {
    "revision": "a75b6991148611ec80ead1f89c5c514c",
    "url": "/bls-polymers/static/media/about-breadcrumb.a75b6991.jpg"
  },
  {
    "revision": "4c79a1c704dcbc9e35f20babd96115ab",
    "url": "/bls-polymers/static/media/about_us_main_image.4c79a1c7.jpg"
  },
  {
    "revision": "33f06f27128cdb7405200bf4c2ed275f",
    "url": "/bls-polymers/static/media/adhesives.33f06f27.png"
  },
  {
    "revision": "c911724c7b91e1aabbb8fea09c7e67b2",
    "url": "/bls-polymers/static/media/background-pattern.c911724c.png"
  },
  {
    "revision": "22970107c8e96b66f1bc061c60e1de86",
    "url": "/bls-polymers/static/media/banner_01.22970107.jpg"
  },
  {
    "revision": "480add1195f477bd1043f16fa3dbe659",
    "url": "/bls-polymers/static/media/banner_1.480add11.png"
  },
  {
    "revision": "fcdffc5d8a24509fd785734e91ea7d72",
    "url": "/bls-polymers/static/media/bg_pipe.fcdffc5d.jpg"
  },
  {
    "revision": "63512c83c1ff85da425ca9166bc6fe46",
    "url": "/bls-polymers/static/media/bls_about_us_body.63512c83.jpg"
  },
  {
    "revision": "6825621e987c4270e5bd1369d2bed207",
    "url": "/bls-polymers/static/media/bls_pattern_2.6825621e.png"
  },
  {
    "revision": "8202075bf96959910e08164bf84d91b5",
    "url": "/bls-polymers/static/media/cable-filling.8202075b.png"
  },
  {
    "revision": "9faaa520db28c269ed3dec159085a295",
    "url": "/bls-polymers/static/media/cable_wire.9faaa520.png"
  },
  {
    "revision": "64858b5853abde23714eb8fa9fbde812",
    "url": "/bls-polymers/static/media/certificate-banner.64858b58.jpg"
  },
  {
    "revision": "13c294dfd7166b6684d76c86503e6529",
    "url": "/bls-polymers/static/media/certificate1.13c294df.png"
  },
  {
    "revision": "7a1d6dcbd9892c9863bcb4825e3d95b2",
    "url": "/bls-polymers/static/media/client-bg.7a1d6dcb.png"
  },
  {
    "revision": "d8c52e90b98540e081cc26520c7d3a50",
    "url": "/bls-polymers/static/media/compound_02.d8c52e90.jpg"
  },
  {
    "revision": "df19f60e8dff8ea9dae4ec4b7e6d0b17",
    "url": "/bls-polymers/static/media/compound_03 (1).df19f60e.jpg"
  },
  {
    "revision": "df19f60e8dff8ea9dae4ec4b7e6d0b17",
    "url": "/bls-polymers/static/media/compound_03.df19f60e.jpg"
  },
  {
    "revision": "f4a665d0d2bb7deda64d87b27e9009c0",
    "url": "/bls-polymers/static/media/contact-banner.f4a665d0.jpg"
  },
  {
    "revision": "bdc65e11f70afcbea8c12f699a6b0b96",
    "url": "/bls-polymers/static/media/erp.bdc65e11.png"
  },
  {
    "revision": "1dfe809843ba9eec3ea36801582b7bbd",
    "url": "/bls-polymers/static/media/events-banner.1dfe8098.jpg"
  },
  {
    "revision": "2fff838ef05f3ce9a1896ad8bc95a1ce",
    "url": "/bls-polymers/static/media/expo.2fff838e.png"
  },
  {
    "revision": "820e8c6276ab60af34f421904153c488",
    "url": "/bls-polymers/static/media/factory_01.820e8c62.jpg"
  },
  {
    "revision": "5e9663771ae0f19979de048851872c01",
    "url": "/bls-polymers/static/media/fda-approved.5e966377.png"
  },
  {
    "revision": "122c5c78c88cf679a054ec18de022c53",
    "url": "/bls-polymers/static/media/fibre-pe-compound.122c5c78.png"
  },
  {
    "revision": "bc397ef5975023a2afd9b3591b0c6d04",
    "url": "/bls-polymers/static/media/investor-banner.bc397ef5.jpg"
  },
  {
    "revision": "f5640c54ff7d8556bb807d7cc6d55cd3",
    "url": "/bls-polymers/static/media/investor-bg.f5640c54.jpg"
  },
  {
    "revision": "7cf3c46b3639f5abc8aed10ee2ee42c9",
    "url": "/bls-polymers/static/media/iso-14001.7cf3c46b.png"
  },
  {
    "revision": "7bd93d9d258f84465b9b138fc58fa543",
    "url": "/bls-polymers/static/media/iso-9001.7bd93d9d.png"
  },
  {
    "revision": "4ff90a8e9c8090ada96b770434d0cab0",
    "url": "/bls-polymers/static/media/layer_18.4ff90a8e.png"
  },
  {
    "revision": "d50c15eb49344c6682f09593c84bf144",
    "url": "/bls-polymers/static/media/layer_1_2.d50c15eb.jpg"
  },
  {
    "revision": "0786d3305d2f8f9158193d4eb8ef8fdc",
    "url": "/bls-polymers/static/media/layer_1_3.0786d330.png"
  },
  {
    "revision": "874b219683e18c2e2069a0fd11989750",
    "url": "/bls-polymers/static/media/layer_59.874b2196.png"
  },
  {
    "revision": "bfe1194c37b60ecc6e42f639428eabc1",
    "url": "/bls-polymers/static/media/layer_60_copy_8_2.bfe1194c.png"
  },
  {
    "revision": "1c7442c330096210368cef687797c7d3",
    "url": "/bls-polymers/static/media/layer_62.1c7442c3.png"
  },
  {
    "revision": "6edfdb0f6ef0754e961557daa215cf70",
    "url": "/bls-polymers/static/media/layer_81.6edfdb0f.png"
  },
  {
    "revision": "3aad8dee2f5b07021c0341be54e7e102",
    "url": "/bls-polymers/static/media/layer_82.3aad8dee.png"
  },
  {
    "revision": "a40deb5eb55719cd142f7273805c53d9",
    "url": "/bls-polymers/static/media/layer_83.a40deb5e.png"
  },
  {
    "revision": "5e44fa7371e7ef4da7096efbbbf84fcb",
    "url": "/bls-polymers/static/media/layer_84.5e44fa73.jpg"
  },
  {
    "revision": "c73fcbc4d87c90f6f2a3cc7b21177d48",
    "url": "/bls-polymers/static/media/layer_91.c73fcbc4.jpg"
  },
  {
    "revision": "ab35ed8ae687140d83964c43ee7f6e93",
    "url": "/bls-polymers/static/media/map.ab35ed8a.png"
  },
  {
    "revision": "b573941d8de7c7ddb1c5409f3cdf9260",
    "url": "/bls-polymers/static/media/noun-arrow-7254257.b573941d.svg"
  },
  {
    "revision": "78915b8b33cfb900e252c87f2f553ddf",
    "url": "/bls-polymers/static/media/pe-compound.78915b8b.png"
  },
  {
    "revision": "a8f467193f528c8b83aeeeb98e1a9850",
    "url": "/bls-polymers/static/media/photo-2024.a8f46719.png"
  },
  {
    "revision": "f9510849b9fb914f2805050b5c71b5a4",
    "url": "/bls-polymers/static/media/pipe-coating.f9510849.png"
  },
  {
    "revision": "61a32c6951e6686eb9b714cea91c13be",
    "url": "/bls-polymers/static/media/pipe_coating_01.61a32c69.jpg"
  },
  {
    "revision": "6c7560644353a09cd1eeed6a3c47eb01",
    "url": "/bls-polymers/static/media/pipe_coating_02.6c756064.jpg"
  },
  {
    "revision": "57819311fb2d6ff1f2c068065028544a",
    "url": "/bls-polymers/static/media/pipe_coating_03.57819311.jpg"
  },
  {
    "revision": "8df2cc1a8f680d7d6d7474858636ea63",
    "url": "/bls-polymers/static/media/plast-alger.8df2cc1a.png"
  },
  {
    "revision": "a5abf08984fbcc7e54ed22f1562bf5b5",
    "url": "/bls-polymers/static/media/plasto.a5abf089.png"
  },
  {
    "revision": "734dee0f1ea16bcb34d22b00a8742d5f",
    "url": "/bls-polymers/static/media/pu-tech.734dee0f.png"
  },
  {
    "revision": "12e7d60ca6a06f65dcbd1fedb9b44790",
    "url": "/bls-polymers/static/media/quality-control.12e7d60c.png"
  },
  {
    "revision": "a41737e109722a9464ac536ab3ed0174",
    "url": "/bls-polymers/static/media/quality.a41737e1.png"
  },
  {
    "revision": "cd11ecbea16edf0d8f0863b1edb0b6ee",
    "url": "/bls-polymers/static/media/rectangle_3_copy.cd11ecbe.png"
  },
  {
    "revision": "c1c85505c1b6d98047c342a8e2df48da",
    "url": "/bls-polymers/static/media/vector_smart_object_5.c1c85505.png"
  },
  {
    "revision": "e7384419f0daf2fb64a0afdec7719ef2",
    "url": "/bls-polymers/static/media/vector_smart_object_7.e7384419.png"
  }
]);